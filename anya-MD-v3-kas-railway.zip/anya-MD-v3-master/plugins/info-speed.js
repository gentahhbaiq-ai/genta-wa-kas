import { createCanvas, loadImage } from '@napi-rs/canvas'
import os from 'os'
import moment from 'moment-timezone'

const BG_URL = 'https://raw.githubusercontent.com/hamm-r/uploader/main/1783477913886-926.jpg'

const WIDTH  = 1280
const HEIGHT = 720

const WIN = {
  accent:      '#0078D4',
  accentLight: '#60CDFF',
  accentGlow:  'rgba(0,120,212,0.35)',
  surface:     'rgba(32,32,32,0.82)',
  surfaceHigh: 'rgba(48,48,48,0.88)',
  stroke:      'rgba(255,255,255,0.08)',
  strokeFocus: 'rgba(0,120,212,0.7)',
  text:        '#ffffff',
  success:     '#6CCB5F',
  warning:     '#FCE100',
  radius:      12,
}

async function getBuffer(url) {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`Fetch failed (${res.status})`)
  return Buffer.from(await res.arrayBuffer())
}

function formatBytes(bytes) {
  if (!bytes) return '0 B'
  const s = ['B','KB','MB','GB','TB']
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${s[i]}`
}

function uptime() {
  let s = Math.floor(process.uptime())
  const d = Math.floor(s / 86400); s %= 86400
  const h = Math.floor(s / 3600);  s %= 3600
  const m = Math.floor(s / 60)
  return `${d}d ${h}h ${m}m`
}

function rrect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arcTo(x + w, y,     x + w, y + r,     r)
  ctx.lineTo(x + w, y + h - r)
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r)
  ctx.lineTo(x + r, y + h)
  ctx.arcTo(x,     y + h, x,     y + h - r, r)
  ctx.lineTo(x,     y + r)
  ctx.arcTo(x,     y,     x + r, y,         r)
  ctx.closePath()
}

function card(ctx, x, y, w, h, { accent = false, elevated = false, r = WIN.radius } = {}) {
  ctx.save()
  ctx.shadowColor   = 'rgba(0,0,0,0.55)'
  ctx.shadowBlur    = 24
  ctx.shadowOffsetY = 6
  rrect(ctx, x, y, w, h, r)
  ctx.fillStyle = elevated ? WIN.surfaceHigh : WIN.surface
  ctx.fill()
  ctx.restore()

  rrect(ctx, x, y, w, h, r)
  ctx.strokeStyle = accent ? WIN.strokeFocus : WIN.stroke
  ctx.lineWidth   = accent ? 1.5 : 1
  ctx.stroke()

  if (accent) {
    ctx.save()
    ctx.beginPath()
    ctx.moveTo(x + r, y + 1)
    ctx.lineTo(x + w - r, y + 1)
    const g = ctx.createLinearGradient(x, y, x + w, y)
    g.addColorStop(0,   'transparent')
    g.addColorStop(0.3, WIN.accent)
    g.addColorStop(0.7, WIN.accentLight)
    g.addColorStop(1,   'transparent')
    ctx.strokeStyle = g
    ctx.lineWidth = 2
    ctx.stroke()
    ctx.restore()
  }
}

/** Set font and return measured width */
function setFont(ctx, size, bold = false, mono = false) {
  ctx.font = `${bold ? '700' : '400'} ${size}px ${mono ? 'monospace' : 'Segoe UI Variable, Segoe UI, sans-serif'}`
}

function txt(ctx, text, x, y, size, {
  bold  = false,
  alpha = 1,
  color = WIN.text,
  align = 'left',
  mono  = false,
} = {}) {
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.fillStyle   = color
  ctx.textAlign   = align
  setFont(ctx, size, bold, mono)
  ctx.fillText(String(text), x, y)
  ctx.restore()
}

function measureTxt(ctx, text, size, bold = false) {
  setFont(ctx, size, bold)
  return ctx.measureText(String(text)).width
}

function progressBar(ctx, x, y, w, h, value) {
  value = Math.max(0, Math.min(100, value))
  const fill = (w * value) / 100
  const r    = h / 2

  rrect(ctx, x, y, w, h, r)
  ctx.fillStyle = 'rgba(255,255,255,0.10)'
  ctx.fill()

  if (fill > 0) {
    const grad = ctx.createLinearGradient(x, y, x + fill, y)
    grad.addColorStop(0, WIN.accent)
    grad.addColorStop(1, WIN.accentLight)
    rrect(ctx, x, y, fill, h, r)
    ctx.fillStyle = grad
    ctx.fill()
  }
}

/** Draw % badge pill */
function badge(ctx, text, cx, cy, color = WIN.accentLight) {
  setFont(ctx, 13, true)
  const tw  = ctx.measureText(text).width
  const pad = 12
  const bw  = tw + pad * 2
  const bh  = 26
  const bx  = cx
  const by  = cy - bh / 2

  rrect(ctx, bx, by, bw, bh, bh / 2)
  ctx.fillStyle = color + '22'
  ctx.fill()

  rrect(ctx, bx, by, bw, bh, bh / 2)
  ctx.strokeStyle = color + '88'
  ctx.lineWidth = 1
  ctx.stroke()

  ctx.save()
  ctx.fillStyle   = color
  ctx.textAlign   = 'center'
  setFont(ctx, 13, true)
  ctx.fillText(text, bx + bw / 2, cy + 5)
  ctx.restore()

  return bw
}

function divider(ctx, x, y, w) {
  ctx.strokeStyle = WIN.stroke
  ctx.lineWidth   = 1
  ctx.beginPath()
  ctx.moveTo(x, y)
  ctx.lineTo(x + w, y)
  ctx.stroke()
}

function dot(ctx, x, y, color = WIN.success) {
  ctx.beginPath()
  ctx.arc(x, y, 5, 0, Math.PI * 2)
  ctx.fillStyle = color
  ctx.fill()
  ctx.beginPath()
  ctx.arc(x, y, 9, 0, Math.PI * 2)
  ctx.strokeStyle = color + '44'
  ctx.lineWidth = 2
  ctx.stroke()
}

// ─── tick labels BELOW progress bar ──────────────────────────────────────────
function barTicks(ctx, x, y, w) {
  ;[25, 50, 75].forEach(tick => {
    const tx = x + (w * tick / 100)
    ctx.strokeStyle = 'rgba(255,255,255,0.15)'
    ctx.lineWidth   = 1
    ctx.beginPath()
    ctx.moveTo(tx, y)
    ctx.lineTo(tx, y + 5)
    ctx.stroke()
    txt(ctx, tick + '%', tx, y + 15, 10, { alpha: 0.3, align: 'center' })
  })
}

// ═════════════════════════════════════════════════════════════════════════════
async function makeDashboard(conn) {
  const canvas = createCanvas(WIDTH, HEIGHT)
  const ctx    = canvas.getContext('2d')

  // Background
  const bg = await loadImage(await getBuffer(BG_URL))
  ctx.drawImage(bg, 0, 0, WIDTH, HEIGHT)

  ctx.fillStyle = 'rgba(10,10,16,0.74)'
  ctx.fillRect(0, 0, WIDTH, HEIGHT)

  // Mica noise
  ctx.globalAlpha = 0.022
  for (let i = 0; i < WIDTH * HEIGHT * 0.25; i++) {
    ctx.fillStyle = '#fff'
    ctx.fillRect(Math.random() * WIDTH, Math.random() * HEIGHT, 1, 1)
  }
  ctx.globalAlpha = 1

  // Radial blue glow top-center
  const bgGlow = ctx.createRadialGradient(WIDTH / 2, 0, 0, WIDTH / 2, 0, HEIGHT * 0.65)
  bgGlow.addColorStop(0, 'rgba(0,120,212,0.09)')
  bgGlow.addColorStop(1, 'transparent')
  ctx.fillStyle = bgGlow
  ctx.fillRect(0, 0, WIDTH, HEIGHT)

  // ── Data ──────────────────────────────────────────────────────
  const totalRam   = os.totalmem()
  const freeRam    = os.freemem()
  const usedRam    = totalRam - freeRam
  const ramPercent = Math.round((usedRam / totalRam) * 100)

  const cpus       = os.cpus()
  const cpuModel   = (cpus[0]?.model || 'Unknown CPU').replace(/\s+/g, ' ').trim()
  const cpuShort   = cpuModel.length > 44 ? cpuModel.slice(0, 44) + '…' : cpuModel
  const cores      = cpus.length
  const load       = os.loadavg()[0]
  const cpuPercent = Math.min(100, Math.round((load / cores) * 100))

  const users   = Object.keys(global.db?.data?.users || {}).length
  const chats   = Object.keys(global.db?.data?.chats || {}).length
  const plugins = Object.values(global.plugins || {}).filter(v => !v.disabled).length

  const botName = conn.user?.name || 'Anya MD'
  const now     = moment().tz('Asia/Jakarta').format('dddd, DD MMM YYYY • HH:mm:ss')

  const PAD = 30   // outer padding
  const GAP = 12   // inner gap between cards

  // ── ROW 1: Header  y=20 h=96 ─────────────────────────────────
  const hY = 20, hH = 96
  card(ctx, PAD, hY, WIDTH - PAD * 2, hH, { accent: true })

  // Windows logo 4-squares
  const lx = PAD + 28, ly = hY + 28
  const sq = 13, gs = 3
  ;[[0,0,'#0078D4'],[sq+gs,0,'#60CDFF'],[0,sq+gs,'#6CCB5F'],[sq+gs,sq+gs,'#FCE100']].forEach(([dx,dy,c]) => {
    ctx.fillStyle = c; ctx.fillRect(lx+dx, ly+dy, sq, sq)
  })

  txt(ctx, botName.toUpperCase(), lx + sq*2 + gs + 14, hY + 52, 26, { bold: true })
  txt(ctx, 'System Dashboard', lx + sq*2 + gs + 14, hY + 74, 14, { alpha: 0.5 })

  dot(ctx, WIDTH - PAD - 130, hY + 38)
  txt(ctx, 'Online', WIDTH - PAD - 115, hY + 43, 14, { bold: true, color: WIN.success })
  txt(ctx, now, WIDTH - PAD - 10, hY + 72, 13, { alpha: 0.5, align: 'right' })

  // ── ROW 2: 3 Stat cards  y=132 h=108 ────────────────────────
  const sY = 132, sH = 108
  const sW = (WIDTH - PAD * 2 - GAP * 2) / 3
  const statCards = [
    { label: 'UPTIME',  value: uptime(),       sub: 'since last restart', icon: '⏱' },
    { label: 'USERS',   value: String(users),  sub: `${chats} group chats`, icon: '👥' },
    { label: 'PLUGINS', value: String(plugins),sub: 'active modules', icon: '🧩' },
  ]
  statCards.forEach((s, i) => {
    const sx = PAD + i * (sW + GAP)
    card(ctx, sx, sY, sW, sH, { elevated: true })
    txt(ctx, s.icon + '  ' + s.label, sx + 18, sY + 26, 12, { alpha: 0.55, bold: true })
    divider(ctx, sx + 18, sY + 33, sW - 36)
    txt(ctx, s.value, sx + 18, sY + 78, 36, { bold: true, color: WIN.accentLight })
    txt(ctx, s.sub, sx + 18, sY + 97, 12, { alpha: 0.4 })
  })

  // ── ROW 3: RAM + CPU  y=256 h=220 ───────────────────────────
  const pY = 256, pH = 220
  const hW = (WIDTH - PAD * 2 - GAP) / 2

  // — RAM card —
  const rX = PAD
  const barW = hW - 40
  card(ctx, rX, pY, hW, pH, { accent: true })

  txt(ctx, 'RAM USAGE', rX + 20, pY + 28, 13, { bold: true, alpha: 0.6 })
  divider(ctx, rX + 20, pY + 35, hW - 40)

  // badge + used/total on same row, well separated
  const ramBadgeW = badge(ctx, `${ramPercent}%`, rX + 20, pY + 70)

  // used GB
  const usedStr  = formatBytes(usedRam)
  const totalStr = `/ ${formatBytes(totalRam)}`
  txt(ctx, usedStr,  rX + 20,                                pY + 115, 34, { bold: true })
  txt(ctx, totalStr, rX + 20 + measureTxt(ctx, usedStr, 34, true) + 8, pY + 112, 17, { alpha: 0.4 })

  // progress bar — leave room above for ticks label
  const barY = pY + 132
  progressBar(ctx, rX + 20, barY, barW, 8, ramPercent)
  barTicks(ctx, rX + 20, barY + 10, barW)

  txt(ctx, `Process heap: ${formatBytes(process.memoryUsage().rss)}`, rX + 20, pY + 195, 13, { alpha: 0.4, mono: true })

  // — CPU card —
  const cX = PAD + hW + GAP
  card(ctx, cX, pY, hW, pH)

  txt(ctx, 'CPU LOAD', cX + 20, pY + 28, 13, { bold: true, alpha: 0.6 })
  divider(ctx, cX + 20, pY + 35, hW - 40)

  const cpuColor = cpuPercent > 80 ? WIN.warning : cpuPercent > 60 ? '#FF8C00' : WIN.accentLight
  badge(ctx, `${cpuPercent}%`, cX + 20, pY + 70, cpuColor)

  // load avg + cores on separate lines, no overlap
  txt(ctx, load.toFixed(2), cX + 20, pY + 115, 34, { bold: true })
  txt(ctx, 'avg load', cX + 20 + measureTxt(ctx, load.toFixed(2), 34, true) + 12, pY + 112, 17, { alpha: 0.4 })

  progressBar(ctx, cX + 20, barY, barW, 8, cpuPercent)
  barTicks(ctx, cX + 20, barY + 10, barW)

  txt(ctx, cpuShort, cX + 20, pY + 195, 13, { alpha: 0.4, mono: true })

  // ── ROW 4: System info  y=492 h=72 ──────────────────────────
  const siY = 492, siH = 72
  card(ctx, PAD, siY, WIDTH - PAD * 2, siH)

  txt(ctx, 'SYSTEM', PAD + 20, siY + 22, 11, { bold: true, alpha: 0.4 })
  divider(ctx, PAD + 20, siY + 28, WIDTH - PAD * 2 - 40)
  const sysStr = `${os.type()}  •  ${os.platform()} ${os.arch()}  •  Node ${process.version}  •  ${cores} CPU Cores`
  txt(ctx, sysStr, PAD + 20, siY + 52, 15, { mono: true, alpha: 0.7 })

  // ── ROW 5: Taskbar footer  y=580 h=42 ───────────────────────
  const tbY = 580, tbH = 42
  card(ctx, PAD, tbY, WIDTH - PAD * 2, tbH, { r: 8 })

  // Win logo 2×2
  const wlx = PAD + 18, wly = tbY + 13
  const ws = 7, wg = 2
  ;[[0,0,'#0078D4'],[ws+wg,0,'#60CDFF'],[0,ws+wg,'#6CCB5F'],[ws+wg,ws+wg,'#FCE100']].forEach(([dx,dy,c]) => {
    ctx.fillStyle = c; ctx.fillRect(wlx+dx, wly+dy, ws, ws)
  })

  txt(ctx, '© Anya MD by Hamm', wlx + ws*2 + wg + 10, tbY + 27, 13, { alpha: 0.4 })

  txt(ctx, moment().tz('Asia/Jakarta').format('HH:mm'), WIDTH - PAD - 18, tbY + 22, 14, { bold: true, alpha: 0.75, align: 'right' })
  txt(ctx, moment().tz('Asia/Jakarta').format('DD/MM/YY'), WIDTH - PAD - 18, tbY + 36, 11, { alpha: 0.4, align: 'right' })

  return canvas.toBuffer('image/png')
}

let handler = async (m, { conn }) => {
  try {
    await m.react?.('🕐')
    const image = await makeDashboard(conn)
    await conn.sendMessage(m.chat, { image, caption: '📊 *ANYA MD — System Dashboard*' }, { quoted: m })
    await m.react?.('✅')
  } catch (e) {
    console.error(e)
    await m.react?.('❌')
    m.reply(`Error dashboard:\n${e.stack || e.message}`)
  }
}

handler.help    = ['dashboard']
handler.tags    = ['info']
handler.command = /^(ping|speed)$/i

export default handler
