/**
 * Kas / Saldo Group
 *
 * Commands:
 * /start
 * /rekap 26k @galih @asen @bayu @weli +4k
 * /rekap @bayu @asen +4k
 * /minus @asen @galih -2k
 * /total saldo
 *
 * Catatan:
 * - Angka setelah /rekap adalah saldo kas saat ini sebelum transaksi.
 * - Nominal bertanda + pada /rekap adalah uang yang masuk, dibagi rata
 *   kepada member yang di-mention.
 * - /minus mengurangi nominal tersebut dari saldo setiap member yang di-mention
 *   dan juga mengurangi total kas.
 */

const money = (value) => {
  if (!value) return null
  let s = String(value).toLowerCase().replace(/\s/g, '').replace(/rp/g, '')
  let sign = 1

  if (s.startsWith('+')) s = s.slice(1)
  else if (s.startsWith('-')) {
    sign = -1
    s = s.slice(1)
  }

  let multiplier = 1
  if (s.endsWith('jt') || s.endsWith('juta')) {
    multiplier = 1_000_000
    s = s.replace(/juta|jt$/, '')
  } else if (s.endsWith('rb') || s.endsWith('ribu') || s.endsWith('k')) {
    multiplier = 1_000
    s = s.replace(/ribu|rb|k$/, '')
  }

  s = s.replace(/\./g, '').replace(/,/g, '.')
  const n = Number(s)
  return Number.isFinite(n) ? Math.round(n * multiplier * sign) : null
}

const formatMoney = (n) => {
  n = Math.round(Number(n) || 0)
  const sign = n < 0 ? '-' : ''
  return sign + 'Rp' + Math.abs(n).toLocaleString('id-ID')
}

const cleanJid = (jid = '') =>
  String(jid).replace(/:\d+@/g, '@').replace('@lid', '@s.whatsapp.net')

const getMentions = (m) => {
  const raw =
    m.mentionedJid ||
    m.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
    m.msg?.contextInfo?.mentionedJid ||
    []

  return [...new Set(raw.map(cleanJid).filter(Boolean))]
}

const displayName = (jid, m, participants = []) => {
  const p = participants.find(x => {
    const ids = [x.id, x.jid, x.lid, x.phoneNumber].filter(Boolean).map(cleanJid)
    return ids.some(id => id.split('@')[0] === jid.split('@')[0])
  })

  return p?.notify || p?.name || p?.subject || m.pushName || jid.split('@')[0]
}

const ensureLedger = (chat) => {
  chat.kasLedger ??= {
    started: false,
    total: 0,
    members: {},
    history: []
  }

  chat.kasLedger.total = Number(chat.kasLedger.total) || 0
  chat.kasLedger.members ||= {}
  chat.kasLedger.history ||= []
  return chat.kasLedger
}

const save = async () => {
  if (global.db?.write) await global.db.write().catch(console.error)
}

let handler = async (m, { conn, command, text, participants = [] }) => {
  if (!m.isGroup) return m.reply('Fitur kas hanya bisa digunakan di grup.')

  const chat = global.db.data.chats[m.chat] ||= {}
  const ledger = ensureLedger(chat)

  if (command === 'start') {
    ledger.started = true
    ledger.total = 0
    ledger.members = {}
    ledger.history = []
    await save()

    return m.reply(
      `╭─「 KAS STARTED 」
│ Status : Aktif
│ Total  : ${formatMoney(0)}
╰────────────

Gunakan:
• /rekap 26k @nama @nama +4k
• /rekap @nama @nama +4k
• /minus @nama @nama -2k
• /total saldo`
    )
  }

  if (!ledger.started) {
    return m.reply('Kas belum dimulai. Gunakan /start terlebih dahulu.')
  }

  if (command === 'rekap') {
    const mentions = getMentions(m)

    // Nominal transaksi = angka bertanda +. Angka tanpa tanda di awal
    // dianggap sebagai saldo kas sebelum transaksi.
    const tokens = String(text || '').trim().split(/\s+/).filter(Boolean)
    const plusToken = tokens.find(x => /^\+/.test(x))
    const amount = money(plusToken)

    if (!amount || amount <= 0) {
      return m.reply(
        `Format salah.\nContoh:\n/rekap 26k @galih @asen @bayu @weli +4k`
      )
    }

    if (!mentions.length) {
      return m.reply('Mention orang yang ikut rekap.\nContoh: /rekap @bayu @asen +4k')
    }

    // Jika ada nominal tanpa tanda + (mis. 26k), anggap itu saldo awal
    // yang dimasukkan ke total kas sebelum transaksi.
    const plainAmounts = tokens
      .filter(x => !/^[+-]/.test(x))
      .map(money)
      .filter(x => x !== null && x > 0)

    if (plainAmounts.length) {
      const base = plainAmounts[0]
      if (ledger.history.length === 0) ledger.total = base
      else if (ledger.total === 0) ledger.total = base
    }

    const share = amount / mentions.length
    ledger.total += amount

    for (const jid of mentions) {
      ledger.members[jid] = Number(ledger.members[jid] || 0) + share
    }

    ledger.history.push({
      type: 'rekap',
      amount,
      mentions,
      share,
      time: Date.now()
    })

    await save()

    const lines = mentions.map(jid =>
      `• @${jid.split('@')[0]} : +${formatMoney(share)}`
    )

    return conn.sendMessage(
      m.chat,
      {
        text:
          `╭─「 REKAP MASUK 」\n` +
          `│ Dana masuk : +${formatMoney(amount)}\n` +
          `│ Peserta    : ${mentions.length} orang\n` +
          `│ Per orang  : +${formatMoney(share)}\n` +
          `│ Total kas  : ${formatMoney(ledger.total)}\n` +
          `╰────────────\n\n` +
          lines.join('\n'),
        mentions
      },
      { quoted: m }
    )
  }

  if (command === 'minus') {
    const mentions = getMentions(m)
    const tokens = String(text || '').trim().split(/\s+/).filter(Boolean)
    const minusToken = tokens.find(x => /^-/.test(x))
    const amount = money(minusToken)

    if (!amount || amount >= 0) {
      return m.reply(
        `Format salah.\nContoh:\n/minus @asen @galih -2k`
      )
    }

    if (!mentions.length) {
      return m.reply('Mention orang yang saldonya mau dikurangi.')
    }

    const perPerson = Math.abs(amount)
    const totalReduction = perPerson * mentions.length

    if (ledger.total < totalReduction) {
      return m.reply(
        `Saldo kas tidak cukup.\n` +
        `Kas sekarang: ${formatMoney(ledger.total)}\n` +
        `Yang diminta: ${formatMoney(totalReduction)}`
      )
    }

    ledger.total -= totalReduction

    for (const jid of mentions) {
      ledger.members[jid] = Number(ledger.members[jid] || 0) - perPerson
    }

    ledger.history.push({
      type: 'minus',
      amount: -perPerson,
      totalReduction,
      mentions,
      time: Date.now()
    })

    await save()

    const lines = mentions.map(jid =>
      `• @${jid.split('@')[0]} : ${perPerson ? '-' + formatMoney(perPerson) : formatMoney(0)}`
    )

    return conn.sendMessage(
      m.chat,
      {
        text:
          `╭─「 PENGURANGAN 」\n` +
          `│ Dikurangi : ${formatMoney(totalReduction)}\n` +
          `│ Per orang : -${formatMoney(perPerson)}\n` +
          `│ Total kas : ${formatMoney(ledger.total)}\n` +
          `╰────────────\n\n` +
          lines.join('\n'),
        mentions
      },
      { quoted: m }
    )
  }

  if (command === 'total' || command === 'saldo') {
    const entries = Object.entries(ledger.members)
      .sort((a, b) => Number(b[1]) - Number(a[1]))

    const lines = entries.length
      ? entries.map(([jid, saldo]) =>
          `• @${jid.split('@')[0]} : ${saldo >= 0 ? '+' : ''}${formatMoney(saldo)}`
        ).join('\n')
      : 'Belum ada data member.'

    const mentions = entries.map(([jid]) => jid)

    return conn.sendMessage(
      m.chat,
      {
        text:
          `╭─「 TOTAL SALDO 」\n` +
          `│ Kas grup : ${formatMoney(ledger.total)}\n` +
          `╰────────────\n\n` +
          lines,
        mentions
      },
      { quoted: m }
    )
  }
}

handler.help = ['start', 'rekap', 'minus', 'total saldo']
handler.tags = ['group']
handler.command = ['start', 'rekap', 'minus', 'total', 'saldo']
handler.group = true
handler.admin = true

export default handler
