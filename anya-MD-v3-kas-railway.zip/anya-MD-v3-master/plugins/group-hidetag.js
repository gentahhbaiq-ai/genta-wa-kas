// Code By Xnuvers007
// Fix LID + Force Mention By ChatGPT 🗿 + Media Support

import { generateWAMessageFromContent, proto } from '@itsliaaa/baileys'

const cleanJid = jid => {
  if (!jid) return ''
  if (typeof jid !== 'string') jid = String(jid)
  return jid.replace(/:\d+@/g, '@')
}

const fixJid = async (conn, jid) => {
  jid = cleanJid(jid)

  try {
    const data = await conn.findUserId(jid) // Mencari nomor asli di balik LID
    return cleanJid(data?.phoneNumber || data?.jid || jid)
  } catch {
    return jid
  }
}

let handler = async (m, { conn, text, participants }) => {
  let mentions = []

  // Kumpulkan & bersihkan semua JID peserta (termasuk yang pakai LID)
  for (let mem of participants) {
    let rawJid = mem.jid || mem.phoneNumber || mem.participant || mem.id || mem.lid
    let jid = await fixJid(conn, rawJid)

    if (jid) mentions.push(jid)
  }

  // Ambil teks dari parameter, atau dari pesan yang di-reply
  let teks = text || m.quoted?.text || m.quoted?.caption || ''

  // =========================
  // ✅ JIKA ME-REPLY PESAN (GAMBAR/VIDEO/STIKER/TEKS)
  // =========================
  if (m.quoted) {
    // Clone pesannya dan paksa masukin mentions pakai cMod
    let msg = conn.cMod(m.chat, m.quoted.vM, teks, conn.user.jid, { mentions })
    return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  // =========================
  // ✅ JIKA HANYA PERINTAH TEKS BIASA
  // =========================
  if (!teks) throw 'Masukin teksnya atau reply pesan yang mau di-hidetag!'

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      extendedTextMessage: proto.Message.ExtendedTextMessage.fromObject({
        text: teks,
        contextInfo: {
          mentionedJid: mentions // Tag disembunyikan di dalam contextInfo
        }
      })
    },
    { quoted: m }
  )

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  })
}

handler.help = ['hidetag', 'h']
handler.tags = ['group']
handler.command = /^(hidetag|h)$/i

handler.admin = true
handler.group = true

export default handler